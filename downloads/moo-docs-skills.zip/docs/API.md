# Moo HTTP API 全量文档

> 版本基线：0.6.579（2026-11-28）· 适用架构：fnOS x86_64 / arm64（Go 后端 + React 前端单二进制服务）
>
> 本文档覆盖 Moo 对外提供的全部 117 个 HTTP 端点，含请求/响应结构、SSE 事件协议、认证与安全模型、构建部署流程。文中不出现任何真实主机地址、凭据或令牌；示例一律使用占位符。

---

## 目录

1. [总则与约定](#1-总则与约定)
2. [认证与可信通道](#2-认证与可信通道)
3. [通用类型](#3-通用类型)
4. [SSE 事件协议](#4-sse-事件协议)
5. [系统与状态](#5-系统与状态)
6. [应用目录](#6-应用目录)
7. [安装 / 更新 / 卸载 / 下载](#7-安装--更新--卸载--下载)
8. [应用控制与信息](#8-应用控制与信息)
9. [应用源管理](#9-应用源管理)
10. [收藏](#10-收藏)
11. [设置](#11-设置)
12. [备份与缓存清理](#12-备份与缓存清理)
13. [FPK 下载缓存](#13-fpk-下载缓存)
14. [后台任务](#14-后台任务)
15. [加速源（镜像）](#15-加速源镜像)
16. [官方应用中心连接（OAuth）](#16-官方应用中心连接oauth)
17. [通知系统](#17-通知系统)
18. [Moo 自更新](#18-moo-自更新)
19. [错误处理](#19-错误处理)
20. [安全模型](#20-安全模型)
21. [构建与部署全流程](#21-构建与部署全流程)
22. [官方应用中心](#22-官方应用中心apiofficial)
23. [fnOS 系统更新](#23-fnos-系统更新apisysupdate)
24. [下架黑名单](#24-下架黑名单blacklistjson)

## 1. 总则与约定

### 1.1 基址

| 通道 | 基址 | 说明 |
|---|---|---|
| 面板 WebUI（推荐） | `http://<NAS_IP>:5666/app/moo/api/` | 经 fnOS 应用中心网关代理，自动携带面板会话 → **可信通道** |
| 直连（可信设备） | `http://<NAS_IP>:38100/api/` | 服务默认监听端口，可被 `MOO_WEB_PORT` 环境变量覆盖 |

- 所有端点路径以 `/api/` 开头；非 `/api` 路径回退 SPA 前端（`index.html`）。
- 服务仅监听**回环与本机面板代理**可达的地址面；写操作一律要求可信通道 + 管理员（见 §2）。
- 静态资产（`/app/moo/` 下 JS/CSS/图标）由同一服务提供。

### 1.2 编码

- 请求/响应均为 UTF-8 JSON（除明确标注的二进制/HTML/SSE 端点）。
- `Content-Type: application/json`（POST/PUT 必须）；响应 `Accept-Encoding: gzip` 时 JSON 透明压缩（SSE 与二进制直通不压缩）。
- 列表类大响应（如 `GET /api/apps`）带 **ETag**，支持 `If-None-Match` → `304` 协商缓存。

### 1.3 端点统计（2026-11-28 按代码重算，共 117 条）

| 域 | 数量 |
|---|---|
| 系统与状态 | 8 |
| 应用目录 | 6 |
| 发现页推荐 | 2 |
| 安装/更新/卸载/下载（SSE） | 11 |
| 应用控制与信息 | 11 |
| 应用源管理 | 13 |
| 收藏 | 2 |
| 设置 | 8 |
| 备份与缓存 | 6 |
| FPK 下载缓存 | 6 |
| 后台任务 | 4 |
| 加速源 | 7 |
| 面板与 Mate 协作 | 2 |
| 通知系统 | 14 |
| Moo 自更新 | 3 |
| 官方应用中心 | 12 |
| KSpeeder 独立应用 | 2 |
| **合计** | **117** |

### 1.4 上限与超时（2026-10-01 API 审计）

| 项 | 值 | 位置 |
|---|---|---|
| 操作历史 `history` | 最近 **20 条**（超出丢最旧） | `internal/operation/queue.go` |
| 官方商店列表缓存 | **10 分钟** TTL，拉取失败回退旧缓存 | `internal/api/official.go` |
| 请求头读取超时 | **10s**（网关 unix socket 与 TCP 调试口一致） | `cmd/server/main.go` |
| 空闲连接超时 | **120s** | `cmd/server/main.go` |
| 响应写超时 | **不设**（故意）：安装/更新/向导走 SSE 长流，向导单次最长 12 分钟 | `cmd/server/main.go` |
| 请求体大小上限 | **10MB**（`http.MaxBytesReader`，超出 400） | `internal/api/server.go` |

> 端点清单由 `internal/api/api_docs_test.go` 双向守护：新增/改路由而漏改本文档会直接测试失败。

---

## 2. 认证与可信通道

Moo 采用**两层防线**：

1. **可信通道判定**：请求必须来自 fnOS 面板代理（网关注入的可信标记）或本机回环。`GET /api/version` 的 `trusted` 字段反映当前请求是否走可信通道。
2. **管理员校验（requireAdmin）**：全部写操作与敏感读操作经 `requireAdmin` 中间件——要求可信通道**且**当前会话为 fnOS 管理员。非可信/非管理员访问写端点返回 `403`。
3. **变更请求校验头（0.6.207-panel D2，CSRF 纵深防御）**：`requireAdmin` 覆盖的端点里，
   凡**非 `GET`/`HEAD`/`OPTIONS`** 的请求必须携带自定义头 `X-Moo-Admin`（前端固定值 `1`，由 `apiFetch` 自动附加）；
   缺失返回 **400**：
   `{"error":"缺少请求校验头（X-Moo-Admin），请刷新 Moo 页面后重试"}`。
   机制：跨站 simple 请求（表单 POST / `no-cors` fetch）无法附加自定义头（需 CORS 预检，而网关无 CORS 头），
   即使平台网关不校验 `Origin`，CSRF 也在应用层被封死。**只读 GET 豁免**。
   手工 `curl` 调写接口：`curl -H 'X-Moo-Admin: 1' -H 'Content-Type: application/json' …`。

只读端点（目录浏览、应用详情、运行状态等）允许未登录访问（面板内浏览场景），因此**不要在只读端点泄露敏感数据**；配置类写端点永不开放匿名。

面板账号（`panel_enabled`/`panel_username`/`panel_password`）是 Moo 用来调用 fnOS 应用中心（appcenter daemon）的**本机回环**凭据，只存本机 `config.json`，永不通过 API 回显明文密码（`panel_has_password` 仅返回布尔）。

---

## 3. 通用类型

### 3.1 AppInfo（应用统一视图）

`GET /api/apps` 元素与 `GET /api/apps/{key}` 响应。

| 字段 | 类型 | 说明 |
|---|---|---|
| `key` | string | 应用唯一键（`appname` 或 `appname@源名`，同名多源共存时带后缀） |
| `appname` | string | 平台应用名（appcenter 标识） |
| `display_name` | string | 展示名 |
| `description` | string | 描述 |
| `installed` | bool | 本机是否已装 |
| `installed_version` / `latest_version` | string | 已装版本 / 源内最新版 |
| `installed_fpk_version` / `available_version` | string | FPK 包版本 / 可更新版本 |
| `update_from_source` | string | 更新策略（0.6.272）= origin/lineage 时更新目标的来源源名（跨源同宗）；空 = 安装源自身 |
| `has_update` | bool | 有可用更新（已忽略时为 false） |
| `update_ignored` | bool | 更新已被用户忽略 |
| `update_ignored_pending` | bool | 已忽略但确实压着新版本（角标计数含此类） |
| `user_hidden` | bool | 该卡被用户「禁用」（0.6.326）：列表/搜索/推荐不展示；已装卡仍列出（可恢复），详情按 key 可达 |
| `platform` / `app_type` / `category` | string | 平台 / 类型 / 分类 |
| `release_url` / `release_notes` | string | 上游发布链接 / 说明 |
| `upstream_source` / `upstream_repo` | string | 溯源（0.6.326）：包发布仓库 owner 与本源码 owner 不同 ⇒ 判定「搬运上游」——`upstream_repo` = 上游 `owner/repo`（恒有），`upstream_source` = Moo 已添加的该上游源名（未添加则空） |
| `upstream_version` / `upstream_url` | string | 上游源同名卡最新版本 / 上游仓库地址（非搬运卡全空） |
| `status` | string | 已装应用运行状态（平台提供） |
| `reco_color` | string | 0.6.536：仅 `GET /api/recommended` 下发——该推荐位在远程清单里指定的极光配色 `aurora-1`..`aurora-12`；空 = 前端按应用名哈希取色（其它接口恒空） |
| `start_stop` / `uninstallable` | bool? | 可启停 / 可卸载能力位 |
| `web_protocol` / `web_url` / `web_port` / `web_path` | string/int | Web 入口 |
| `web_on_webui` | bool | Web 入口是否在 WebUI 内 |
| `web_service_name` / `service_port` | string/int | 服务名 / 服务端口 |
| `homepage` | string | 主页 |
| `icon_url` | string | 图标直链（可能指向源数据域，抓取受 SSRF 防护约束） |
| `updated_at` | string | 源更新时间 |
| `download_count` | int? | 应用级累计下载量（官方 / 源声明 / GitHub 全版本累计） |
| `download_current` | int? | 当前版本资产的下载量（GitHub Releases；详情页展示） |
| `download_scope` | string? | 下载量口径：`official` / `source` / `github` / `github_current` |
| `local_installs` | int | 本机经 Moo 安装/更新累计次数 |
| `post_install_note` | string | 安装后提示 |
| `source` | string | 来源源名 |
| `maintainer` / `maintainer_url` / `distributor` / `distributor_url` | string | 维护者 / 分发者 |
| `changelog` | string | 原始更新日志 |
| `changelog_entries` | [{version, text}] | 解析后的版本化条目（最新在前） |
| `size_bytes` / `sha256` | int64/string | FPK 包大小 / 校验 |
| `preview_count` / `preview_urls` | int/string[] | 预览图数量 / 直链 |
| `has_readme` | bool | 是否有 README |
| `same_name_count` | int | 0.6.312 B2 去重展示层：同名组卡片数（**精确 `appname`**，仅阶梯代表卡承载）；>1 = 有重复 |
| `same_name` | SameNameEntry[] | 同名组全部卡片（**仅详情下发**，列表瘦身剥离；见 §3.1.1） |
| `same_name_ci_count` | int | 0.6.579 D3：与本卡 `appname` **大小写不敏感相同、字面不同**的其它卡数（>0 才下发，0 省略）。**纯展示提示**——后端不合并、不隐藏任何卡，列表卡数量与 `/api/dedup` 计数逐字不变 |
| `same_name_ci` | SameNameEntry[] | 0.6.579 D3：大小写同名变体卡（**仅详情下发**）。与 `same_name` **互补**（只装字面不同的卡，每条 `case_variant=true`）⇒ 两者并集 = 大小写不敏感全组，前端合并渲染无重复行 |

#### 3.1.1 SameNameEntry（同名 / 同名变体候选条目）

```json
{
  "key": "1panel@ZJB518", "source": "ZJB518", "display_name": "1Panel",
  "version": "2.0.14", "arch": "x86", "installed": false, "is_rep": true,
  "origin": "hxido-rxm/fndepot", "sha256": "…",
  "source_is_fork": true, "upstream_repo": "hxido-rxm/fndepot",
  "is_upstream": false, "case_variant": true
}
```

- `is_rep`：该卡是当前展示的那张（列表路径 = 阶梯代表卡；详情路径 = `!Hidden`）。
- `origin` / `sha256`：归一发布仓库 / 最新包 sha（同宗、同构建判定用；列表路径不带）。
- `upstream_repo`：该卡被判定「搬运上游」时的上游 `owner/repo`；**空 = 未判定为搬运**（即原项目源）。
- `is_upstream`：本卡发布仓库 == 同组某张兄弟卡声明的 `upstream_repo`。
- `case_variant`（0.6.579）：本条与目标卡 `appname` 大小写不敏感相同、字面不同；
  只有 `same_name_ci` 里的条目为 `true`（`same_name` 恒缺省）。

### 3.2 SourceEntry（应用源）

```json
{
  "id": "src-xxxx", "name": "FnDepot", "url": "https://…/fndepot.json",
  "app_count": 123, "enabled": true, "favorite": false,
  "error": "", "last_fetched": "2026-09-29T12:00:00+08:00", "empty_streak": 0,
  "last_verdict": "alive", "verdict_at": 1795789256,
  "overlap_risk": "high", "overlap_with": "other-src",
  "overlap_name_count": 53, "overlap_exact_count": 33,
  "overlap_name_ratio": 0.5, "overlap_exact_ratio": 0.31,
  "overlap_unique_names": 53, "overlap_self_count": 106
}
```

- `error`：最近一次同步失败原因（成功时为空）。
- `empty_streak`：连续 0 应用同步轮次（自动监测据此停用空源）。
- `last_verdict` / `verdict_at`（0.6.575+）：源有效性判定结果（`alive` / `dead` / `uncertain`，表示直连与镜像是否都确认失效）与判定时间（unix 秒）；无判定记录时两字段都省略。
- `overlap_*`（0.6.326z）：**源重合率（只读信号，绝不影响任何源的状态）**——该源与
  「最相似的对方源」的应用名/版本重合情况，用于让「同 owner 且 `fork=false` 的整仓
  复制源」可见（这是溯源判定（`lineage`）看不到的盲点）。口径与 FnDepot 对齐：
  - `overlap_name_ratio = overlap_name_count / max(两源应用数)`；`overlap_exact_ratio` 同理
    （精确 = 同名同版本）。
  - `overlap_risk`：`high` ≥0.80 / `medium` ≥0.50 / `low` ≥0.25 / `none` <0.25，且需满足
    **最小证据量**（`overlap_name_count` 或 `overlap_exact_count` ≥2）——只共享 1 个应用名
    不足以构成重合结论（现网 114 条信号中 29 条交集=1，其中 26 条是「各只有 1 个应用的源
    互相指向」）。证据不足时档位回落 `none`，但 `overlap_with` / 各 ratio / 各 count 照常
    下发（数据零丢失，仅不下发给视图）；无 partner 或比值低于 `low` 时其余字段可缺省。
  - `overlap_unique_names`：本方独有 appname 数（「停掉它会丢多少」——只看比值会误导，
    大源天然高重合，故与比值同时下发）。
  - `overlap_with`：最相似的对方源名（平票取源名字典序小者，结果确定）。
  - 官方源（`fnos-official`）不参与计算，其条目恒无这些字段。

### 3.3 BackgroundTask（后台任务）

```json
{
  "id": "dl-xxxx", "appname": "someapp", "op": "download",
  "status": "running", "step": "下载中", "progress": 42.5,
  "message": "…", "new_version": "1.2.3",
  "downloaded": 1048576, "total": 4194304, "speed": 524288
}
```

`op` ∈ `install | update | download`；`status` ∈ `running | done | error`。

### 3.4 MirrorHealth（加速源健康快照）

```json
{
  "mirrors": [{"key": "gh-proxy", "url": "https://…/", "ok": true, "latency_ms": 120, "speed_mbps": 8.2}],
  "selected": "auto", "active": "gh-proxy",
  "last_probe": "2026-09-29T12:00:00+08:00",
  "last_switch": {"from": "jsdelivr", "to": "gh-proxy", "reason": "测速优选", "ts": "…"},
  "interval_s": 300
}
```

Docker 组同构（`/api/mirrors/docker/health`）。

`GET /api/mirrors/health?refresh=1`（0.6.578+）：用户触发路径走 **single-flight + 5 秒防抖**——并发 N 个请求只真跑一轮，其余复用这一轮的结果，并在响应里带 additive 字段 `"throttled": true`（旧前端忽略即可）；响应体其余结构与普通快照同构。

`mirrors[].status` = `ok | limited | fail | ""`（0.6.333 F2 起新增 `limited` = 429 限流：链路可达但临时受限——冻结连败计数、不计入「全部加速源不可用」判定、不参与优选排名；`error` 在 fail/limited 时给原因短语）。

### 3.5 Settings（设置页全量视图）

`GET /api/settings` 响应字段（全部为当前生效值）：

`check_interval_hours`, `mirror`, `mirror_include_direct`（0.6.321 F7，默认关）, `mirror_options[]`, `docker_mirror`, `docker_mirror_options[]`, `custom_github_mirror`, `custom_docker_mirror`, `custom_github_mirrors[]`（0.6.521）, `custom_docker_mirrors[]`（0.6.521）, `install_volume`, `volume_options[]`, `download_dir`, `auto_update`, `auto_correct`（0.6.326 引入；0.6.326x 已弃用，并入 `update_policy=upstream`）, `catalog_language`, `update_policy`, `dedup_policy`, `source_auto_care_disabled`, `source_list_url`, `source_list_disabled`, `github_token`（0.6.334，只写；GET 仅回 `github_token_set` 布尔）, `panel_enabled`, `panel_username`, `panel_base_url`, `panel_has_password`, `backup_dir`, `backup_auto`, `backup_interval_days`, `cache_clean_days`, `cache_clean_every_days`, `gh_probe_hours`, `gh_probe_minutes`, `dk_probe_hours`, `dk_probe_minutes`, `proxy_enabled`, `proxy_url`, `dock_order[]`, `settings_tab_order[]`, `official_scope_mode`（2026-11-26，官方源授权范围偏好，恒为 `full` / `minimal`）。

字段语义与 `PUT /api/settings` 的指针语义见 §11。

### 3.6 FpkDownloadFile（下载缓存条目）

```json
{"name": "appname-x.y.z.fpk", "size": 7704517, "mod_at": "…",
 "appname": "appname", "display_name": "应用名", "installed": false}
```

---

## 4. SSE 事件协议

长操作（安装/更新/卸载/下载/自更新/目录重载）返回 `text/event-stream`。每条事件为一行：

```
data: {"step":"install","progress":42,"message":"下载中…"}
```

| step | 语义 |
|---|---|
| `<操作名>`（install/update/uninstall/download/downloading/verifying/installing…） | 进行中；`progress` 0–100（下载类为精确值，其它为阶段值），`message` 人类可读进度 |
| `done` | 成功终态，`progress=100`，`message` 结果摘要 |
| `error` | 失败终态，`error` 字段为原因 |

约定：
- **终态唯一**：流以 `done` 或 `error` 之一结束；客户端不得把「连接断开」当成功。
- 客户端断开后**操作在后台继续**（进度可经 `GET /api/operations` / `GET /api/tasks` 轮询恢复）。
- 事件带 `"id": <opID>`：断流后可用 `GET /api/operations/{id}/events` 续传（见 §5.6）。
- 轮询恢复路径的可靠性：终态按操作 ID 从 history 取回（防 running→error 窗口误报完成）。
- 自更新 SSE 另有阶段词：`downloading` → `verifying` → `installing` → `done`/`error`（§18）。

---

## 5. 系统与状态

### 5.1 `GET /api/version`（公开）
```json
{"version": "0.6.206", "trusted": true}
```
`trusted` = 当前请求是否来自可信通道（前端据此决定是否提示登录）。

### 5.2 `GET /api/status`（公开）
```json
{"version": "0.6.206", "platform": "fnos"}
```

### 5.3 `GET /api/about`（公开）
关于信息（版本、构建时间、许可等）。

0.6.384：更新日志与文档卡改为读远程清单（目录见设置项 `about_lists_url`，
空=内置公网默认；目录下 `changelog.md` / `docs.md` / `devdocs.md`）：
- `changelog`：远程更新日志全文；远程不可达时回落构建内嵌文本
- `changelog_source`：`remote` / `embedded`
- `changelog_version`：远程文件里第一个版本文（无=运行版本）
- `docs` / `devdocs`：`[{title, desc?, url}]`，前端只展示标题与说明，
  链接以「打开」「复制」按钮提供

拉取策略与推荐清单一致：10 分钟 TTL + SWR + 2 分钟失败退避；冷启动最多
同步等 1.5s。内网清单地址需显式开启 `source_list_allow_private`。

### 5.3.1 `POST /api/about/lists/refresh`（admin）
丢弃缓存立即重拉三个清单文件（改完远程清单即时生效）。
```json
{"ok": true, "changelog_source": "remote", "changelog_version": "0.6.384", "docs": 6, "devdocs": 5}
```

### 5.3.2 `GET /api/about/mem`（公开）

关于页「内存占用（实时）」数据源：**进程级内存快照**，只读 `/proc/self/statm` 与
Go 运行时统计，不触发任何远程清单刷新（与 `/api/about` 分离，可安全轮询）。

```json
{"rss_bytes": 83927040, "heap_bytes": 39601280, "sys_bytes": 79096088, "goroutines": 874}
```

- `rss_bytes`：常驻集（读不到 `/proc/self/statm` 时为 0，前端隐藏该行）；
- `heap_bytes`：Go 堆已分配（`HeapAlloc`）；`sys_bytes`：运行时向 OS 申请总量；
- `goroutines`：当前协程数；
- 响应带 `Cache-Control: no-store`，中间层不得缓存。

### 5.4 `GET /api/daemon/status`（公开）
```json
{"available": true}
```
appcenter daemon（fnOS 应用中心 RPC，本机 unix socket）是否可达。不可达时安装/更新不可用，健康自检会推 `health_error` 事件。

### 5.5 `GET /api/operations`（公开）
```json
{"current": {BackgroundTask|操作视图} | null, "history": [操作视图…]}
```
当前操作 + 历史（SSE 断线后的进度恢复入口）。
**上限**：`history` 固定保留**最近 20 条**（超出丢弃最旧，见 `internal/operation/queue.go`），
因此单次响应体有界；`current` 至多 1 条。需要更长的操作留痕请走应用日志。

### 5.6 `GET /api/operations/{id}/events`（公开，SSE）
按操作 ID **跟随一个已有操作**（断线续传，SSE_RESUME）：立即推一条当前状态事件，
之后 700ms 轮询到终态为止；事件格式与安装/更新 SSE 完全一致（`step=queued` /
操作名 / `done` / `error`），且每条事件都带 `"id": <opID>`。

```json
data: {"step":"update","progress":42,"message":"安装中…","id":"3f2a9c1d8b7e4a50"}

data: {"step":"done","progress":100,"message":"更新完成","id":"3f2a9c1d8b7e4a50"}
```

- `id` 不存在 / 已过期（`history` 只留最近 20 条）→ `404` `{"error":"操作不存在或已过期"}`；
  客户端据此退回 `GET /api/operations` 按 `kind`+`target` 兜底匹配。
- 客户端断开 → 连接结束，操作在后台继续；重连后仍能跟随到终态。
- 终态副作用（目录缓存失效、本机安装计数）按 opID **幂等**：多个连接跟随同一操作不会重复执行。

### 5.6b `GET /api/operations/{id}`（公开，JSON）
按操作 ID 查**单条状态**（P0-1 终态轮询兜底）：SSE 与续传都被网关持续掐断时，
客户端每 3~12 秒查一次本端点，直到 `done` / `error`。
```json
{"id":"3f2a9c1d8b7e4a50","kind":"update","target":"fnmonitor","state":"running","msg":"安装中…","progress":42}
```
- `id` 不存在 / 已过期 → `404` `{"error":"操作不存在或已过期"}`（客户端据此退化为后台提示）。
- 终态（`done`/`error`）查询会执行一次**幂等**的终态副作用（目录缓存失效 / 本机安装计数），
  因此即使客户端全程没连上 SSE，轮询到 done 后列表也能立即刷新。
- 默认最多跟随 30 分钟（大包弱网），连续 3 次查不到即放弃。

### 5.6c `GET /api/updates/manual`（requireAdmin，P1-1）
自动更新「需人工处理」队列：聚合 `auto_update_skips.json` 的 wizard（12h）/ blocked（2h）/
unknown（6h）/ channel（2h，需连续两次命中才算数）四类条目，供前端显示数量徽章与清单。
（channel = 平台不允许 FPK 升级通道 10371；0.6.578 起 TTL 12h→2h 且首轮只计数不拦。
注意：默认 `check_interval_hours=0` 为 24h 一轮，2h 条目会在下一轮前过期 → **默认节奏下该缓存不生效**（fail-open，不误拦）；只有轮次间隔 <2h 或 2h 内重复触发时「连续两次命中」才成立。）
```json
{"count":1,"items":[{"app":"trim.openclaw","version":"2026.8.35-6","reason":"unknown","reason_label":"平台任务结果未知（可能仍在执行）","until":"2026-11-22T16:00:00+08:00"}]}
```
- 只读；不触发更新、不改变静默期。
- `until` 到期后条目自动消失（读取时过滤过期项）。

### 5.6d `GET /api/self-update/last`（requireAdmin，P1-2）
上次自更新的对账结果（Moo 启动时对 `self_update_state.json` 求值）：
```json
{"schema_version":1,"from_version":"0.6.556","to_version":"0.6.557","submitted_at":"2026-11-22T08:00:00+08:00","status":"confirmed"}
```
- `status`：`none`（无记录）/ `submitted`（新进程尚未启动）/ `confirmed`（当前版本 == 目标）/
  `failed`（仍是升级前版本，升级未生效）/ `unknown`（两者都不是，需人工核对）。
- 只读；不触发更新，也不自动降级（FPK 升级没有可换回的旧二进制）。

### 5.7 `GET /api/installed`（requireAdmin）
平台视角的已安装应用列表（appcenter 原始数据）。

### 5.8 `GET /api/icons/version`（公开）
图标缓存代次（前端判断是否需刷新图标映射）。

---

## 6. 应用目录

### 6.1 `GET /api/apps`（公开，ETag）
响应 `AppsResponse`：
```json
{"apps": [AppInfo…], "last_check": "2026-09-29T12:00:00+08:00", "upgrade_allowed": true}
```
目录合并所有已启用源 + 官方目录；同名应用多源共存（`key` 带 `@源名`）。支持 `If-None-Match`。

### 6.2 `GET /api/apps/{key}`（公开）
单个 AppInfo 详情。查询参数：
- `wizard=1`：附加安装向导信息（配置项表单 schema）。

详情是候选表的**唯一**下发路径（列表瘦身会剥 `same_name` / `same_name_ci`）：
- `same_name`：字面完全相同的同名组（含被去重隐藏的卡 —— 按 key 可达是逃生门）；
- `same_name_ci`（0.6.579 D3）：大小写同名变体（字面不同、`EqualFold` 相同），
  每条 `case_variant=true`；与 `same_name` 互补，两者并集 = 大小写不敏感全组。
  **只提示、不合并**：该组里没有一张卡因为变体被隐藏，`is_rep` 仍按 `!Hidden` 给出。

### 6.3 `GET /api/recommended`（公开）
发现页推荐位列表。数据来自远程清单 `recommend_list`（纯文本，一行一条
`appname@源名`，`#` 注释；顺序即展示顺序，地址见设置项 `recommend_list_url`）。
0.6.536 起行尾可追加极光配色：`appname@源名 aurora-3`（或裸数字 `3`，也接受
`appname@源名@aurora-3`），随卡片以 `reco_color` 下发；不写则前端按应用名哈希取色。
只返回当前目录里存在的卡：缺卡 / 已去重隐藏 / 用户禁用的条目**整条跳过**，
不随机补位、不留空位。`?count=N`（1–12）只做上限裁剪。

拉取策略（0.6.380）：**请求路径不阻塞**——缓存 10 分钟；过期后先返回上一次
成功值并在后台单飞刷新（stale-while-revalidate）；冷启动（无任何缓存）最多
同步等 2.5s，超时立刻回内嵌清单兜底。清单地址是 GitHub 时**镜像优先、直连
最后**（单候选 8s 超时），避免直连不可达时每个 TTL 周期首请求卡十几秒。

### 6.3.1 `POST /api/recommended/refresh`（admin）
丢弃缓存立刻重拉清单（改完远程清单即时生效）。
```json
{"ok": true, "url": "https://…/recommend_list.txt", "count": 4, "entries": ["moo-mate@Blue-Mink", "…"], "colors": ["aurora-11", "…"]}
```

### 6.4 `GET /api/installed-detail`（公开）
已安装应用的平台详情（状态/启停/入口）。

### 6.5 `GET /api/search/source-keys`（公开）
源链接归一化检索（搜索贴源链接用）：
```json
[{"key": "github.com/owner/repo", "names": ["FnDepot", "某源名"]}]
```
把仓库根 / raw 前缀 / 路径 / v1v2 索引 / CDN 镜像等形式归一到 `github.com/owner/repo`（或 fndepot JSON 索引键）。

### 6.6 `GET /api/dedup`（公开）
去重展示策略当前值 + 两档可见卡数（首页去重胶囊预览）。
```json
{"policy": "all", "total": 2771, "one": 1331, "merged": 1331}
```
`policy` ∈ `all`（默认，不去重，全部卡片）/ `one`（去重，每个 appname 留一张
代表卡，代表卡优先「非搬运」的真实项目源）。分组口径 = **精确 `appname`**；
0.6.579 D3 的「大小写同名变体」（52 组 / 105 张同时可见）**只提示不合并**，
因此 `total` / `one` 与引入该提示前逐字一致（不给变体计数开新档、不减可见卡）。`total` / `one` 分别为两档下
列表可见卡数；`merged` 为旧三档「标准档」的兼容字段，**已废弃**，值恒等于
`one`。策略由 `PUT /api/settings` 的 `dedup_policy` 字段设置（`merge` 仍接受
但归一为 `one`）。

---

## 7. 安装 / 更新 / 卸载 / 下载

以下端点均为 **requireAdmin + SSE**。`{key}` 为 AppInfo.key（URL 编码）。

| 端点 | 说明 |
|---|---|
| `POST /api/apps/{key}/install` | 安装（下载 FPK → 校验 sha256 → appcenter 安装/升级） |
| `POST /api/apps/{key}/stage` | 仅下载+暂存 FPK（SSE 进度；供「先下载、后弹安装向导」流程使用，下载完成后 `GET /wizard` 缓存命中） |
| `POST /api/apps/{key}/update` | 更新到 `available_version`（保留 @appdata 数据） |
| `POST /api/apps/{key}/uninstall` | 卸载（走平台标准管线） |
| `POST /api/apps/{key}/download-task` | 仅下载 FPK 到缓存（不安装），生成可暂停/续传任务 |
| `POST /api/apps/{key}/task/pause` | 暂停下载任务 |
| `POST /api/apps/{key}/task/resume` | 恢复下载任务 |
| `POST /api/apps/reload` | 重载目录（SSE；等价于全量刷新后重建目录） |
| `POST /api/check` | 检查更新（并发 8 全量源刷新 + 比对已装版本） |
| `PUT /api/apps/{key}/ignore-update` | 忽略该应用的更新（可重复忽略不同版本） |
| `DELETE /api/apps/{key}/ignore-update` | 取消忽略 |
| `PUT /api/apps/{key}/hide` | 禁用（0.6.326）：从列表/搜索/推荐隐藏；已装卡仍列出（可恢复），详情按 key 可达 |
| `DELETE /api/apps/{key}/hide` | 取消禁用（恢复显示） |

`PUT/DELETE /api/apps/{key}/hide` 为幂等切换，响应 `{"ok":true,"hidden":[...]}`（`hidden` = 当前禁用集合，上限 500）。
`{key}` 原样存（前端传卡片 key，如 `appname@源名`），构建期按卡片 key 精确匹配、回落 `appname`；仅展示层，不改更新判定（对比「忽略更新」：后者压更新信号）。

安装/更新成功时 `local_installs[appname]` 累计 +1 并持久化。

`POST /api/check` 响应：
```json
{"updated": 155, "failed": 2, "total_apps": 2093, "updated_apps": 7}
```
（`updated`/`failed` 为源数；`updated_apps` 为有新版本的已装应用数。）

---

## 8. 应用控制与信息

| 端点 | 权限 | 说明 |
|---|---|---|
| `POST /api/apps/{key}/start` | admin | 启动已装应用（平台服务） |
| `POST /api/apps/{key}/stop` | admin | 停止 |
| `GET /api/apps/{key}/panel-detail?appname=…` | admin | 面板侧应用详情（账号/端口/状态） |
| `GET /api/apps/{key}/wizard` | 公开 | 取安装向导字段：非官方应用 `StageOnly` 暂存后 `FetchWizard`；**官方应用**走面板下载链（最长 12 分钟），返回 `{appname, has_wizard, fields…}`，失败时 `has_wizard=false` + `error` |
| `GET /api/apps/{key}/asset?type=…&index=N&u=…` | 公开 | 远端资源代理透传（见下） |
| `GET /api/apps/{key}/diagnostic?step=…&error=…` | 公开 | 应用诊断（0.6.269 起启用）：只读收集 report（应用/版本/架构/失败步骤/错误/日志尾部 ≤50 行/平台）+ `issue_url`，供前端上报页一键生成 issue 内容，不改动任何状态 |

`asset` 查询参数：
- `type=icon`：应用图标（本地缓存优先，miss 时代理抓取；源数据 URL 受 SSRF 防护：仅公共地址）。
- `type=preview&index=N`：第 N 张预览图（同样缓存 + 防护）。
- `type=readme`：README 渲染源（`u` 传原始 URL，30s 超时透传，失败回退占位）。

---

## 9. 应用源管理

全部 **requireAdmin**。`{id}` 为 SourceEntry.id。

| 端点 | 请求体 | 说明 |
|---|---|---|
| `GET /api/sources` | — | 源列表 `[SourceEntry]` |
| `POST /api/sources` | `{"name":"…","url":"https://…"}` | 添加单源（url 必填；支持 fndepot JSON 索引 / conversun 目录 / 官方源列表形式） |
| `POST /api/sources/batch` | `{"items":[{"name":"…","url":"…"}]}` | 批量添加（逐条校验；重复 URL 去重并回 `deduped` 友好计数） |
| `POST /api/sources/reorder` | `{"order":["id1","id2",…]}` | 调整排序（须全量排列） |
| `POST /api/sources/sync-list` | — | 按内置源列表地址同步源清单（开启自动同步时周期执行） |
| `POST /api/sources/restore-defaults` | — | 一键恢复默认源列表（补齐缺失 + 同 URL 去重保一；官方源不删） |
| `POST /api/sources/delete-defaults` | `?dry_run=1` | 一键删除历史默认源（地址归一后命中旧 157 条默认清单；官方 OAuth 源与自加源不受影响；`dry_run=1` 只预检不落变更） |
| `POST /api/sources/{id}/sync` | — | 刷新单源 |
| `POST /api/sources/sync-all` | — | 一键刷新所有**已启用**源（并发 8；手动触发，不计自动监测轮次） |
| `POST /api/sources/{id}/toggle` | — | 启用/停用切换 |
| `POST /api/sources/{id}/rename` | `{"name":"新名"}` | 重命名 |
| `POST /api/sources/{id}/favorite` | — | 关注（星标）切换；关注源新增应用/报表变化触发通知 |
| `DELETE /api/sources/{id}` | — | 删除源（已装应用不受影响） |

自动监测策略（`source_auto_care_disabled` 可整体停用）：每轮全量刷新后，「成功但 0 应用」连续 5 次的源自动停用并沉底。

---

## 10. 收藏

| 端点 | 权限 | 说明 |
|---|---|---|
| `GET /api/favorites` | admin | 收藏列表（`[key]`，顺序 = 收藏先后） |
| `POST /api/favorites` | admin | 切换收藏：`{"key":"appname@源名"}`；上限 500 条 |

收藏持久化于 `config.json`，重启保留。发现页「收藏列表」按此渲染；收藏应用有更新触发 `favorite_update` 通知。

---

## 11. 设置

### 11.1 `GET /api/settings`（admin）
返回 §3.5 Settings 全量视图。

### 11.2 `PUT /api/settings`（admin）
局部提交 + **指针语义**：
- 字符串字段（如 `custom_github_mirror`、`proxy_url`、`panel_base_url`、`download_dir`、`backup_dir`）：JSON 中**存在**（含空串）= 显式设置/清除；**缺省** = 不改动。
- 布尔字段（`auto_update`、`proxy_enabled`、`backup_auto`、`panel_enabled`、`source_list_disabled`…）：指针语义同上（缺省 = 不改动）。
- 数值字段（`gh_probe_hours`…、`cache_clean_days`…）：越界整单拒绝。
- `install_volume`（0.6.325 G2）：指针语义 —— **缺省** = 不改动；`0` = 清除回「系统默认」（安装走系统默认卷自动探测）；`1-8` = 指定存储卷；负数 / `>8` 整单拒绝。`GET /api/settings` 原样返回该值（`0` 不再显示成 `1`，保证「系统默认」可往返）。
- `check_interval_hours` / `backup_interval_days` / `cache_clean_every_days`（0.6.325 H5）：指针语义 —— **缺省** = 不改动；`0` = 清除回各自默认（检查间隔 **24h** / 备份周期 **7 天** / 清理周期 **1 天**；`GET /api/settings` 透出生效值）。校验：`check_interval_hours` 合法 `0-168`，越界整单拒绝；两个天数字段负数整单拒绝、`>30` 沿用既有钳制（落 `30`）。
- 0.6.521 起支持多条自定义加速源：`custom_github_mirrors[]` / `custom_docker_mirrors[]` 为整表替换（`nil`=不改、`[]`=清空），单值字段同步为第一条；只提交单值字段时仅在显式改动时替换列表，避免旧前端回传把其它条目清掉。
- `custom_github_mirror` / `custom_docker_mirror` / `source_list_url` 随 `GET /api/settings` 透出（0.6.325 H1 修复：此前 PUT 可写但 GET 恒缺键，设置页水合空串后全量保存会静默清除已存自定义镜像）；未设置时键缺席（omitempty），前端水合成空串。
- `dock_order` / `settings_tab_order`：非空提交必须是**完整排列**（全量提交防脏序）。
- `update_policy`（0.6.272 跨源更新策略；0.6.326x 起新增第四档 `upstream`）：仅接受 `auto`（0.6.532「自动（推荐）」= `lineage` + 上游纠正，搬运应用跟上游原作者）/ `strict`（默认，只认安装源）/ `origin`（同发布仓库）/ `lineage`（同作者或同发布仓库）/ `upstream`（**强制上游**：已安装且来自「搬运上游」的应用改用上游原作者版本，其余应用按 `strict` 处理），其余整单拒绝；变化后目录缓存失效、下次 `/api/apps` 重建。
- `dedup_policy`（0.6.312 B2 列表去重展示策略；0.6.575 两档化）：接受 `all`（默认，不去重、零变化）/ `one`（每 appname 一张代表卡，代表卡优先真实项目源），其余整单拒绝；旧值 `merge`（已取消的「标准档」）仍接受但归一为 `one`。变化后目录缓存失效。只并展示身份，不动版本/更新判定；`GET /api/dedup` 返回两档可见数。
- `official_scope_mode`（2026-11-26 加固 A，官方源 OAuth 授权范围偏好）：只接受 `full` / `minimal` / `""`（空串 = 完整权限，默认），**其余整单拒绝（400）**。只影响**下一次**发起授权，不改已连接会话；`minimal` = 仅 `trim.appcenter.all`（只读官方目录与版本），`full` = 既有 9 项权限。落盘失败时回滚到提交前的值（配置文件与运行态严格一致）。
- `auto_correct`（0.6.326 引入；0.6.326x 起**已弃用**）：语义已并入 `update_policy="upstream"`（强制上游）。字段仍可提交以兼容旧客户端（提交 `true` 等价于把 `update_policy` 置为 `upstream`），保存设置后恒为 `false`；新代码请直接用 `update_policy`。

常用片段示例：

```json
{"proxy_enabled": true, "proxy_url": "socks5://127.0.0.1:1080"}
{"mirror": "auto", "docker_mirror": "daocloud", "auto_update": true}
{"backup_dir": "", "backup_auto": true, "backup_interval_days": 7}
```

校验规则摘要：
- `mirror`/`docker_mirror` ∈ 选项键集合（`auto`/镜像 key/`direct`/`custom`）；`custom` 须配对应自定义地址。
- `proxy_url` 非空时 scheme 必须 ∈ `http|https|socks4|socks5|socks5h` 且带 host；`proxy_enabled=true` 时地址必填（整单拒绝）。代理配置**保存即生效**（运行时动态 transport），仅 GitHub 域名改道。
- `panel_base_url` 必须是回环地址（fnOS 面板 127.0.0.1:5666 形态）。
- `download_dir` 必须是可访问的 /volN 目录；切换会迁移缓存，失败整单拒绝。
- 备份目录须可写（空串 = 回本机默认数据目录）。

### 11.3 `POST /api/settings/proxy-test`（admin）
科学加速代理连通性测试（**不保存**、不影响当前生效配置，单独校验给定地址）：
```json
请求：{"proxy_url": "http://127.0.0.1:7890"}
响应：{"ok": true, "latency_ms": 350}          // 或
      {"ok": false, "error": "…connection refused", "latency_ms": 12}
```
经代理 HEAD `https://github.com`（12s 超时）。

### 11.4 `GET /api/settings/download-dirs`（admin）
可选下载目录列表（卷根 + 卷下顶层共享目录）。

### 11.5 `GET /api/settings/download-dirs/browse?path=/vol1`（admin）
目录浏览（目录选择器用；逐层下钻，返回子目录名）。

### 11.6 `GET /api/settings/docker-mirror/status`（admin）
Docker 优选镜像源状态：读 daemon.json 的 `registry-mirrors` 当前值。
```json
响应：{"mirrors": ["docker.fnnas.com"], "docker_active": true,
       "applied_at": "…", "mirror": "…", "backup_file": "…"}   // 末三项仅应用过时有值
```

### 11.7 `POST /api/settings/docker-mirror/apply`（admin）
应用优选镜像源：备份 daemon.json（滚动 5 代）→ 合并写 `registry-mirrors`
（原子 rename）→ `systemctl restart docker` → 读回验证，失败自动回滚；
daemon.json 损坏时拒绝写入。
`mirror` 取值：预设名（DockerMirrorOptions key）、`custom`（配 `custom_url`）、
`direct`（清空 registry-mirrors 回直连）、`auto`（0.6.325 起支持）。
`auto` = 并发实测所有有 URL 的 Docker 加速源（kspeeder 本地源探
127.0.0.1:5443），选延迟最低的可达源应用；全部不可达返回 502 诚实报错
（列出尝试数量），不改动任何配置。
```json
请求：{"mirror": "auto", "custom_url": ""}      // mirror=预设名/auto/custom/direct
响应：{"ok": true, "mirrors": ["…"], "backup_file": "…",
       "auto_mirror": "1panel", "auto_label": "1Panel", "auto_latency_ms": 120}
// auto_* 三字段仅 mirror=auto 时出现 = 实际选中源；或 {"ok": false, "error": "…"}
```

---

### 11.8 `GET /api/mate/github-token`（admin，0.6.354）供本机 **Moo Mate** 复用 Moo 已配置的 GitHub API token（伴侣侧不再单独保存凭据）。
必须额外携带 `X-Moo-Mate: 1`（伴侣专用标记）；缺头 → 403。
```json
响应：{"github_token_set": true, "github_token": "ghp_…"}   // 未配置时 set=false、token=""
```
token 只出现在响应体，不写日志；Moo Mate 侧缓存 2 分钟，不会逐请求调用。

### 11.9 `GET /api/mate/mirrors`（admin，0.6.380）
供本机 **Moo Mate** 复用 Moo 的 GitHub 加速镜像表（伴侣侧自更新下载按它展开
候选，不再维护第二份列表）。必须携带 `X-Moo-Mate: 1`，缺头 → 403。
```json
响应：{"prefixes": ["https://…/", "…"], "count": 3}
```
只返回**状态 ok 且按吞吐降序**的前缀（最多 6 个）；无健康数据时按设置里的
声明顺序回退。不返回任何凭据。Mate 侧缓存 10 分钟（空结果也缓存）。

---

## 12. 备份与缓存清理

| 端点 | 权限 | 说明 |
|---|---|---|
| `GET /api/backups` | admin | 备份列表（config.json 全量快照 + 数据目录归档） |
| `POST /api/backups` | admin | 立即创建一份备份（`backup_auto` 开启时另有周期备份） |
| `DELETE /api/backups/{name}` | admin | 删除指定备份 |
| `GET /api/backups/{name}/download` | admin | 下载备份文件（二进制） |
| `POST /api/backups/{name}/restore` | admin | 从备份恢复（先自动兜底再覆盖，失败保留现场） |
| `POST /api/backups/clean` | admin | 清理应用缓存（图标/README 等）中过期文件 |
| `GET /api/logs` | admin | 在线查看应用日志（moo.log 末尾 N 行，`?lines=` 默认 200、上限 2000；含文件大小、轮转归档清单与 `archive_bytes` 归档总字节） |
| `POST /api/logs/cleanup` | admin | 清理应用日志（0.6.500）：body `{"keep_days":N}`，N=0 全部清空、N>0 删除 N 天前的日志行（保留最近 N 天）；返回 `removed_files` / `freed_bytes` / `kept_bytes`。当前日志原地截断重写（保留 inode），过滤后为空的归档直接删除 |

`POST /api/backups/clean` 请求体：
```json
{"days": 7}      // 清理 >7 天缓存（days 缺省用 cache_clean_days 配置）
{"force": true}  // 强制清空全部缓存文件（仍只动 cache 目录，绝不碰已下载 FPK/已装应用）
```
响应：`{"removed": 3, "bytes_freed": 6291456, "remaining": 154}`。

备份目录语义：`backup_dir` 空 = 本机数据目录 `backups/`；可为 /volN 下任意目录（手机/电脑可同步）。

---

## 13. FPK 下载缓存

| 端点 | 权限 | 说明 |
|---|---|---|
| `GET /api/fpk-downloads` | admin | 已下载 FPK 列表 `[FpkDownloadFile]` |
| `DELETE /api/fpk-downloads/{name}` | admin | 删除缓存包 |
| `POST /api/fpk-downloads/upload` | admin | 上传本地 FPK（multipart 字段 `file`，仅 `.fpk`，≤512MB，同名覆盖；返回 `{name,size,replaced}`，上传后即可列表内安装） |
| `POST /api/fpk-downloads/batch-delete` | admin | 批量删除缓存包（body `{names:[...]}`，≤500 项；非法名/失败逐项回 `failed`，文件已不存在计入 `deleted`；返回 `{deleted,failed}`） |
| `POST /api/fpk-downloads/{name}/install` | admin + SSE | 用缓存包安装/升级（跳过下载阶段） |
| `GET /api/fpk-downloads/{name}/wizard` | admin | 探测缓存包安装向导定义（直读 FPK 内 wizard/install，无需 staging） |

---

## 14. 后台任务

| 端点 | 权限 | 说明 |
|---|---|---|
| `GET /api/tasks` | 公开 | 任务列表 `[BackgroundTask]`（下载任务带 id，可区分新旧终态） |
| `DELETE /api/tasks/{id}` | admin | 清除终态任务记录 |

---

## 15. 加速源（镜像）

GitHub 加速组（源同步/图标/readme/自更新下载的前缀镜像）与 Docker 镜像组（系统级拉取参考）独立配置。

| 端点 | 权限 | 说明 |
|---|---|---|
| `GET /api/mirrors/health` | admin | GitHub 组健康快照（§3.4） |
| `GET /api/mirrors/docker/health` | admin | Docker 组健康快照（含本地 KSpeeder 缓存） |
| `GET /api/datadir-health` | admin | 数据目录自监控（0.6.574）：生效目录/来源/归属标记 + `Save` 守卫拒绝与写盘失败计数（进程内累计） |
| `POST /api/mirrors/check` | admin | 立即手动测速（两组各自全量候选） |
| `POST /api/mirrors/sync` | admin | 立即从远端清单刷新加速源列表（免重建 FPK；45s 超时，清单不可达回 502） |
| `POST /api/mirrors/restore` | admin | 清空本机屏蔽集合（删掉的默认源全部回来）并重拉远端清单 |
| `POST /api/mirrors/hidden` | admin | 本机屏蔽加速源（`auto`/`custom`/`direct` 永不可屏蔽） |

语义：
- `mirror=auto`：按测速优选，切换触发 `mirror_switched` 通知（30 分钟冷却防抖）。
- 测速**直连**各镜像（不经科学加速代理）——测的是镜像本身质量。
- 自动测速间隔由 `gh_probe_*` / `dk_probe_*` 齿轮配置（0h0m = 默认 5 分钟）。
- 全部候选失败 → `mirrors_all_failed`（Docker 组对偶 `docker_mirrors_all_failed`），恢复 → `mirrors_recovered`。

清单目录化（0.6.512 起）：`lists/github_mirrors.txt` / `lists/docker_mirrors.txt` 一行一条
`key|label|url|description`（`url` 可空，对应 `auto`/`custom`/`direct`）。远端拉取成功即覆盖
内置清单，失败保留上一次成功值（离线不受影响）。

- `POST /api/mirrors/sync`：立即重拉两份清单，响应 `{"ok":true,"github":N,"docker":M}`；
  两份都失败回 502（内置清单继续生效，不影响下载）。
- `POST /api/mirrors/hidden`：body 支持三种写法——`{"keys":[...]}` 全量覆盖、
  `{"add":["k"]}` 追加、`{"remove":["k"]}` 移除；`{"keys":[]}` = 全部恢复显示。
  屏蔽集合持久化在配置里，与远端清单无关（清单更新不会复活被删的源）。
- `POST /api/mirrors/restore`：清空屏蔽集合并重拉清单；响应 `{"ok":true,"github":N,"docker":M}`，
  拉取失败时回 `{"ok":false,"restored":true,"error":"…"}`（屏蔽已清空）。

`POST /api/mirrors/check` 响应示例（0.6.321 起 fail 条目带 `error` 原因短语）：

```json
{
  "github_mirrors": [
    {"key": "gh-proxy-hk", "label": "GH-Proxy HK", "latency_ms": 45, "speed_bps": 1461372, "status": "ok"},
    {"key": "gh-fast", "label": "GHFast", "latency_ms": 0, "status": "error", "error": "403 拒绝"}
  ],
  "docker_mirrors": [
    {"key": "daocloud", "label": "DaoCloud", "latency_ms": 88, "status": "ok"}
  ]
}
```

- 顶层恒两键 `github_mirrors` / `docker_mirrors`（单点 writeJSON，结构上不可能缺键）；字段名是 **`github_mirrors`**，不是选项 key 前缀——按 `gh_mirrors` 之类子串查找会 0 命中。
- `status` = `ok | limited | error`（服务端 `checkStatus` 映射：ok→ok、**429 限流→limited（0.6.333 F2，链路可达、临时性）**、其余→error）；`error`（0.6.321 F6，可选字段）在 fail 与 limited 时有值：`429 限流（临时）` / `403 拒绝` / `HTTP 5xx` / `慢（10s 读 NKB < 512KB 门槛）` / `连接被拒` / `DNS 解析失败` / `探测资产 404（资产下线或未代理）`。
- `direct` / `auto` / `custom` 无探测 URL、不入池、不出现在响应；例外：设置 `mirror_include_direct=true`（0.6.321 F7，默认关）时 `direct` 以合成候选（0.6.333 F1 起直接用 `https://` + release 资产探同一 pinned 文件）出现并参与排名。
- `speed_bps` 仅 GitHub 组（吞吐测速）；Docker 组测速只影响速度列、不改可达判定。

### 15.1 KSpeeder 安装包（远端清单）

0.6.524 起 KSpeeder 卡片不再内置固定下载地址，改为读远端清单（`lists/kspeeder.txt`，
不可达时用内置版本兜底并退避 2 分钟），下载后按清单做 sha256 + 字节数双重校验。

| 端点 | 权限 | 说明 |
|---|---|---|
| `GET /api/kspeeder/latest` | admin | 当前架构的最新条目（最多等 25s） |
| `POST /api/kspeeder/install` | admin + SSE | 下载 → 校验 → 走与应用源相同的暂存/向导/平台安装管线（最长 15 分钟） |

`GET /api/kspeeder/latest` 响应：
```json
{"ok": true, "arch": "amd64", "version": "0.8.9", "filename": "kspeeder_0.8.9_amd64.deb",
 "url": "https://…", "sha256": "665e76bc…", "size": 6459687}
```

`POST /api/kspeeder/install` 为 SSE 流（§4），阶段词 `stage → download → verifying → installing →
done|error`；已存在且校验通过的安装包会跳过下载。

---

## 16. 官方应用中心连接（OAuth）

> 0.6.255 起**面板账号已从设置中彻底移除**，官方应用中心改为纯 OAuth 免登录连接。
> 原面板账号连通性测试端点已下线。官方源授权入口见
> `POST /api/official/authorize-headless`（请求体临时携带面板账号，不落盘）
> 与前端「应用源 → 飞牛应用中心 → 🔑」对话框（fnOS 1.2.0800+ 走 iframe 内嵌授权页）。

---

## 17. 通知系统

形式对齐 fn-knock 事件中心：**渠道**（外部推送通道）+ **规则**（逐事件开关）+ **记录**（流水）。

> 本节全部端点 **requireAdmin**，唯 `GET /api/notify-view/{id}` 例外（卡片跳转目标，公开 + 一次性令牌）。

### 17.1 渠道 CRUD

| 端点 | 说明 |
|---|---|
| `GET /api/notify-channels` | 渠道列表（敏感参数脱敏回显） |
| `POST /api/notify-channels` | 新建渠道 |
| `PUT /api/notify-channels/{id}` | 更新渠道 |
| `DELETE /api/notify-channels/{id}` | 删除渠道 |
| `POST /api/notify-channels/{id}/test` | 对已存渠道发测试消息 |
| `POST /api/notify-channels/test` | 测试**未保存草稿**（弹窗内即时验证） |

渠道结构（`type` ∈ `wecom | dingtalk | feishu | serverchan | pushplus | bark | webhook`）：
```json
{
  "id": "ch-xxxx", "type": "wecom", "name": "企微群", "enabled": true,
  "params": {"webhook_url": "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=<KEY>"},
  "timeout": 10,
  "format": "card"
}
```
`params` schema 随 type 变化（webhook_url / sendkey / token / devicekey…）；`format` ∈ `""/markdown`（默认）、`markdown_v2`（表格/富文本）、`card`（卡片，需 `view_base` 详情页地址，未配置自动降级）。

### 17.2 设置与规则

`GET /api/notify-settings`（admin）：
```json
{
  "enabled": true,
  "events": {"install_success": true, "welcome": true, "…": true},
  "catalog": [{"key": "install_success", "label": "安装成功", "desc": "…", "group": "应用生命周期", "default": true}],
  "mem_alert_mb": 256, "cpu_alert_pct": 80, "view_base": ""
}
```
`PUT /api/notify-settings`：局部提交（`enabled`、`events` 部分键、阈值、`view_base`）。
规则语义：**事件 key 缺失 = 目录缺省；仅显式 false 为关**。关闭的事件既不推送也不入记录。

事件目录（41 类，6 组）：

| 组 | 事件 key |
|---|---|
| 应用生命周期 | `install_success` `install_error` `update_success` `update_error` `uninstall_success` `uninstall_error` `download_done` `download_error` `backup_done` `backup_error` |
| 应用更新 | `updates_available` `favorite_update` `auto_update_round` `upstream_corrected` `favorite_source_apps` `favorite_source_report` |
| Moo 自身 | `welcome` `store_update_available` `store_update_success` `store_update_error` `resource_mem_alert` `resource_cpu_alert` `health_error` `health_recovered` `disk_space_alert` `notify_channel_error` |
| 源与网络 | `source_sync_failed` `source_recovered` `source_auto_disabled` `source_auto_recovered` `source_auto_heal_capped` `source_sync_summary` `mirror_switched` `mirrors_recovered` `mirrors_all_failed` `docker_mirrors_all_failed` `docker_mirrors_recovered` `official_session_expired` |
| 系统 | `official_session_encrypt_mismatch` `system_update_available` |
| 数据面 | `catalog_drop` |

### 17.3 记录与触发

| 端点 | 说明 |
|---|---|
| `GET /api/notify-log` | 通知流水（含各渠道发送结果；上限 `NotifyLogCap` 条） |
| `POST /api/notify-log` | 手动写入一条记录：`{"event":"…","msg":"…","ok":true}` |
| `POST /api/notify-log/clear` | 清空记录 |
| `POST /api/notify/fire` | 手动触发任意事件（规则行门铃调试）：`{"event":"install_success"}` |
| `POST /api/notify/welcome` | 重发欢迎语（默认测试渠道） |
| `GET /api/notify-view/{id}?t=<token>` | 通知详情页（卡片跳转目标；HTML，一次性令牌） |

---

## 18. Moo 自更新

### 18.1 `GET /api/store-update`（公开）
```json
{"current_version": "0.6.206", "has_update": false, "last_check": "…", "error": ""}
{"current_version": "0.6.206", "has_update": true, "available_version": "0.6.207", "…": "…"}
```
探测源：GitHub Releases（走加速源候选顺序：优选镜像 → 自定义 → 直连；直连候选经科学加速代理）。**非 amd64 架构不提供自更新**（官方仅发 x86 FPK）。私有仓库探测恒 404 → 仓库转 public 后红点才生效。

### 18.2 `POST /api/store-update`（admin + SSE）
就地自更新管线（daemon 升级）：
```
data: {"step":"downloading","message":"下载 v0.6.207 安装包…","progress":0}
data: {"step":"verifying","message":"校验安装包…"}
data: {"step":"installing","message":"提交飞牛应用中心就地升级…"}
data: {"step":"done","progress":100,"message":"…"}      // 或 {"step":"error","error":"…"}
```
错误分支：已有任务进行中 / 探测失败 / 已是最新 / release 缺 FPK 资产 / 下载失败 / sha256 校验失败 / 提交升级失败。成功后推 `store_update_success` 通知。

下载通道（0.6.380）：候选为**加速镜像在前、直连最后**（最多 3 个镜像，按吞吐
排序）；单通道有首字节 12s / 连续 20s 无进展的看护，卡死即换下一个通道，不再
等 8 分钟总超时。每个通道下载完都必须过 **minisign 验签 + sha256** 双校验，
镜像只能改传输、改不了包。

---

## 19. 错误处理

统一错误体（非 2xx）：
```json
{"error": "人类可读原因（中文）"}
```

| 状态码 | 语义 |
|---|---|
| 400 | 请求体/参数非法（指针语义冲突、越界、URL 不合法、地址校验失败） |
| 403 | 非可信通道或非管理员访问写/敏感端点 |
| 404 | 端点/资源不存在（源 id、备份名、下载文件名、notify-view 令牌无效） |
| 409 | 资源冲突（同名源、重复任务等） |
| 501 | 端点未实现（如 `diagnostic`） |
| 502 | 上游失败（面板 RPC、代理抓取失败） |
| 500 | 内部错误 |

约定：**整单拒绝**——一个字段非法则整个请求 400，不落任何部分状态。

---

## 20. 安全模型

| 层 | 机制 |
|---|---|
| 网络面 | 服务监听面最小化：写操作全部 requireAdmin（可信通道 + 管理员）；面板地址强制回环 |
| 凭据 | 面板密码仅存本机 `config.json`（文件权限 700），API 只回 `panel_has_password` 布尔；通知渠道参数脱敏回显 |
| SSRF 防护 | 源数据驱动的 URL（icon_url/readme_url/preview_urls）抓取前经公共地址校验：拒绝内网/回环/元数据地址 |
| 供应链 | FPK 安装前 sha256 校验；自更新校验 release 资产哈希 |
| 科学加速 | 代理地址只存本机；仅 GitHub 域名改道，镜像/内网流量不经过代理 |
| 日志 | 非 GET 请求打审计日志（方法/路径/remote）；不记录凭据 |
| 备份 | 快照含全量 config（含密码字段）——备份文件权限与目录须受控 |

---

## 21. 构建与部署全流程

### 21.1 仓库结构

```
moo/
├── cmd/server/          # Go 主程序（HTTP 服务 + 后台协程）
│   └── main.go          # 入口：config.Load → netx.SetProxy → source.Manager → api.Server
├── internal/
│   ├── api/             # HTTP 路由与处理器（85 端点）+ SSE + 缓存
│   ├── config/          # config.json 结构/加载/保存
│   ├── source/          # 源同步引擎（fndepot 索引 / conversun 目录 / 官方列表）
│   ├── netx/            # 科学加速出网代理（0.6.206）
│   ├── netguard/        # SSRF 公共地址校验
│   ├── notify/          # 通知渠道 fanout（7 类渠道）
│   ├── operation/       # 长操作状态机（current/history 原子切换）
│   ├── pipeline/        # 安装/更新/卸载管线（下载→校验→appcenter）
│   └── platform/        # fnOS appcenter daemon RPC（unix socket）
├── frontend/            # React + Vite（构建产物 → web/）
├── fnos/                # FPK 描述：manifest + lifecycle（安装/卸载/启停脚本）
├── web/                 # 前端构建产物（随 FPK 分发）
└── docs/API.md          # 本文档
```

### 21.2 构建管线（x86 FPK）

```bash
# 1. 前端（Node 22 + npm；产物输出到 ../web/dist → 拷贝为 web/）
cd frontend && npm run build        # tsc -b && vite build

# 2. 后端（Go 1.25+；版本注入 main.Version）
export PATH=<go>/bin:$PATH
GOOS=linux GOARCH=amd64 go build -ldflags "-X main.Version=0.6.206" \
    -o build/moo-server-x86 ./cmd/server/

# 3. 暂存目录（manifest + 二进制 + web）
STAGING=build/tmp/fnos-x86
rm -rf "$STAGING"; cp -a fnos "$STAGING"
cp build/moo-server-x86 "$STAGING/app/moo-server"
cp -r web "$STAGING/app/web"

# 4. 打包（fnpack）
./build/fnpack build --directory "$STAGING"
mv moo.fpk moo_0.6.206_x86.fpk
sha256sum moo_0.6.206_x86.fpk     # 发布时记录到 Release 尾行
```

### 21.3 安装与运行时目录

| 路径 | 内容 | 升级行为 |
|---|---|---|
| `/vol1/@appcenter/moo/` | 二进制 `moo-server` + `web/` 前端 | FPK 升级覆盖（@appcenter 随包更新） |
| `/vol1/@appdata/moo/` | `config.json`（权限 700）、`cache/`（catalog 快照/图标/readme 缓存）、`backups/`、`moo.log` | **升级保留**（@appdata 数据卷） |

环境变量：
- `MOO_WEB_PORT`：覆盖默认监听端口（默认 38100）。
- `TRIM_PKGVAR`：数据目录根（fnOS 应用框架注入 @appdata 绝对路径）。

生命周期（`fnos/` lifecycle 脚本）：安装 = 释放包 + 起服务；升级 = 停 → 换二进制/web → 起（config.json 不动）；卸载 = 停服务（数据卷默认保留，供重装恢复）。

### 21.4 热替换（开发调试）

```bash
appcenter-cli stop moo
cp <staging>/moo-server /vol1/@appcenter/moo/moo-server
rm -rf /vol1/@appcenter/moo/web && cp -r web /vol1/@appcenter/moo/web
appcenter-cli start moo
curl -s http://127.0.0.1:38100/api/version    # 验证版本
```

### 21.5 发布流程

1. 版本号（`fnos/manifest` + README 徽章）bump。
2. 构建 FPK + sha256 记录。
3. 源码同步到发布仓库（git push main）。
4. GitHub Release：`v0.6.206` + FPK 资产 + 更新日志（一行亮点 + 一句说明 + FPK sha 尾行模板）。
5. 仓库须为 **public**，自更新红点探测才生效（私有仓库探测恒 404）。

### 21.6 后台协程（服务内常驻）

| 协程 | 职责 | 周期 |
|---|---|---|
| 源自动同步 | 全量刷新已启用源（并发 8） | `check_interval_hours`（默认 24h） |
| 源自动监测 | 空源停用/沉底 | 随每轮同步 |
| GitHub 加速组测速 | 优选镜像切换 | `gh_probe_*`（默认 5m） |
| Docker 加速组测速 | 优选 + KSpeeder 参考 | `dk_probe_*`（默认 5m） |
| 自更新探测 | GitHub Releases 探测 | 周期性 + 手动「立即检查」 |
| 自动更新应用 | `auto_update` 开启时对「有更新」应用走标准管线（排除 Moo 自身防自更新环） | 随源刷新轮次 |
| 自动备份 | config 快照写入备份目录 | `backup_interval_days`（默认 7d） |
| 缓存自动清理 | 删除超龄缓存文件 | `cache_clean_every_days` |
| 健康自检 | daemon RPC 可达性 + 5 分钟告警/恢复 | 5m |
| 资源告警 | 内存 >256MB / CPU >80% 持续 5 分钟告警 | 30m 冷却 |
| 磁盘告警 | 数据目录使用率 >90% | 30m 冷却 |

---

## 22. 官方应用中心（`/api/official/*`）

飞牛官方应用中心（面板 `/ogh/ac/h` 代理）的 OAuth 连接与商店浏览。Token 由 `internal/official`
管理（PKCE 授权码 + 自动刷新 + 落盘持久化），商店列表 **10 分钟缓存**（拉取失败回退旧缓存）。

| 端点 | 权限 | 说明 |
|---|---|---|
| `GET /api/official/status` | 公开 | 连接状态（是否已授权、token 过期时间等）。0.6.254 起含 `ui_supported`/`ui_known`：本机面板前端是否支持 /signin PKCE 授权页（仅 fnOS 1.2.0800+ 前端支持，旧版只渲染普通登录页）；`ui_known=false` = 检测中。2026-11-26（加固 C/B2）起含 `can_admin`（非管理员视角会裁掉 `panel_base`/`panel_base_source`/`last_error`，仍 **200**）与 **公开**布尔 `session_encrypted`（磁盘上的会话文件是否加密形态）、`encryption_available`（本机密钥是否可用）；加固 A 起再加 `scope_mode`（配置里的授权范围偏好 `full`/`minimal`，非法值按 `full`）与 `scope_minimal_supported`（恒 `true`，前端据此展示两个选项） |
| `GET /api/official/authorize` | admin | 开始授权：返回 `{url}`，前端打开该 URL 完成登录后带 `code` 回调。0.6.253 起支持 `?base=http(s)://<主机:端口>` 指定用户浏览器可达的面板地址（仅 http/https、无 URL 凭据；缺省用本机回环）。加固 A 起支持 `?scope=full\|minimal`（**白名单**，其它值 **400**；缺省 `full` = 旧客户端行为完全不变）：`full` = 既有 9 项权限，`minimal` = 仅 `trim.appcenter.all`（只读目录/版本，不能读写文件或改系统设置） |
| `POST /api/official/callback` | admin | 完成授权：body `{code}`，成功 `{ok:true}`。加固 A 起：`minimal` 范围被面板拒绝（换 token 回 `invalid_scope`）→ **400** + `{"error":…,"error_code":"scope_rejected","scope":"minimal"}`（pending 保留，可用 full 重试）；其它失败仍 **502** |
| `POST /api/official/cancel` | admin | 取消本次授权（丢弃待交换的 PKCE 对），成功 `{ok:true}` |
| `POST /api/official/authorize-headless` | admin | 0.6.254 无头授权（无浏览器，旧版 fnOS 前端无授权页时的替代路径）：复用面板账号 WS 登录 → `GET /oauthapi/authorize` 取一次性 code → 换 token。成功 `{ok:true}`；面板未配置 400；登录失败/限流 502（附原因）；响应无 code 502（附原始响应片段）。加固 A 起 body 可带 `scope`（`full`/`minimal`，缺省 `full`；非法值 **400**，且在面板登录**之前**校验） |
| `POST /api/official/logout` | admin | 断开授权：清 token，成功 `{ok:true}` |
| `POST /api/official/session-encryption` | admin | 2026-11-26 会话落盘加密开关（opt-in，默认关）：body `{enabled:bool}`（缺 `enabled` **400**）。开启时立即把当前会话按新形态重写一次（外层 `{"v":2,"enc":"enc:v1:…","note":…,"access_token":""}`，旧版本读到「未连接」而非报错），并写 `official_session_encrypt` 到配置；本机密钥不可用 → **400**；配置落盘失败 → 回滚运行态与标志后 **500**。成功 `{ok:true, encrypted:bool}`（`encrypted` = 此刻磁盘上的会话文件是否为密文形态） |
| `GET /api/official/apps` | admin | 商店全量列表 `{total, list}`（10 分钟缓存） |
| `GET /api/official/search?keyword=…` | admin | 关键词搜索 `{total, list}`；`keyword` 为空返回 **400** |
| `GET /api/official/apps/{name}` | admin | 单个应用详情（面板 StoreDetail 透传） |

约定：

- 上游不可达/未授权统一 **502**（`writeErr`），`status` 除外（它只回报本地状态）。
- 列表缓存命中时不打上游；`POST /api/official/callback`/`logout` 会改变授权态，之后首次 `apps` 重新拉取。
- **0.6.253 通道接线**：OAuth 会话有效时，官方目录（`Panel.Apps`）、详情回填、安装前 sourceID 查询（`panelApp`）优先走本 OAuth 通道（免面板登录、不受面板限流影响）；会话缺失或通道故障时自动回退面板 WS 通道（含 0.6.252 失败退避）。接线实现见 `internal/api/official_oauth_wiring.go`。
- **0.6.254 版本门控**：/signin 的 PKCE 授权页仅 fnOS 1.2.0800+ 面板前端有（懒加载 oauth chunk；旧版前端零 OAuth 逻辑，浏览器打开授权链接只见普通登录页）。启动时探测本机面板前端（`internal/official/support_probe.go`，进程内缓存），前端按 `ui_supported` 分流：支持 → iframe 授权页流程；不支持 → 无头授权（`authorize-headless`，面板账号一次性登录取码，授权后目录仍免面板登录）。
- 该域原为**主线（moo-w）独有**；2026-10-01 两条线合并后（面板线为基线 + 摘入官方模块），
  发布线同样具备这些端点。

## 23. fnOS 系统更新（`/api/sysupdate`）

只提示、不安装：采集 fnOS 本体是否有系统更新（与面板「设置 → 更新和还原 → 系统更新」同源判断），
命中时走通知事件 `system_update_available`（六变体、同版本只推一次）。

| 端点 | 权限 | 说明 |
|---|---|---|
| `GET /api/sysupdate` | admin | 读 12h 缓存，不触发网络。返回 `{current, latest, available, kernel_current, kernel_latest, notes[], branch, checked_at, ok, err?}` |
| `POST /api/sysupdate/check` | admin | 强制刷新（忽略缓存）；命中且该版本未推送过时同时推送渠道通知 |

数据源与边界：

- 当前版本：`/usr/trim/etc/version`；当前内核：`/proc/sys/kernel/osrelease`。
- 可用版本：`GET https://apiv2-liveupdate.fygonas.com/`（公网、无鉴权，返回 `branchId` / `kernel` / `packages[]`，取 `packageName=="trim"` 的 `version`）。
- 该接口给的是**稳定分支**最新包；面板偶尔出现的更高版本属灰度通道（WS `liveupdate.check` + 会话密钥签名），
  公开接口未发布时这里不会误报，也不会触发通知。
- 失败静默降级（`ok=false` + `err`），不影响其它接口；`MOO_SYSUPDATE_API` / `MOO_SYSUPDATE_VERSION_FILE` / `MOO_SYSUPDATE_KERNEL_FILE` 可覆盖默认值（独立实例验收用）。

### 11.10 `GET /api/auto-update/dep-map`（admin，0.6.549）

「允许自动停用的应用」弹窗用：返回**应用 → 它依赖的运行时**映射，前端在应用名下方标注
`依赖 nodejs_v24`，并据此把有依赖的应用置顶。

平台没有「应用依赖谁」的正向接口，Moo 对每个已装应用调 daemon `stop/check` 反查后反转
（并发 6，结果缓存 10 分钟；单个应用失败忽略）。

```json
{
  "runtimes": { "nodejs_v24": ["com.dustinky.qwenpaw", "fnclearup"] },
  "apps": { "com.dustinky.qwenpaw": ["nodejs_v24"] },
  "checked_at": "2026-11-14T01:20:00+08:00"
}
```

## 24. 下架黑名单（`blacklist.json`）

远端维护的「停止分发」清单：改文件即生效，不用发版。清单由发布者用 **minisign**
签名（与自更新共用同一把公钥，`.minisig` 缺失或验签失败该候选作废），Moo 每
10 分钟刷新一次（多镜像候选 + last-known-good；**从未成功拉取过 → fail-open**，
空清单绝不误杀）。清单**不内嵌**进安装包（出厂快照恒为空），续期 / 撤下 / 新增条目
都只改远端文件，无需重建发版。

### 24.1 清单结构

```json
{
  "schema_version": 1,
  "updated_at": "2026-11-22",
  "entries": [
    {"app": "openclaw", "source": "*", "reason": "malware", "notice": "内置脚本会执行未知程序", "since": "2026-11-22", "ref": "issue#123"},
    {"app": "badapp", "sha256": "<64位hex>", "reason": "policy", "until": "2026-12-31"},
    {"sha256": "<64位hex>", "reason": "malware"}
  ]
}
```

| 字段 | 说明 |
|---|---|
| `app` | 应用名，大小写不敏感。**允许为空**，当且仅当 `sha256` 合法（按包指纹拦，不看名字）。`"*"` 被拒绝（一行写错会隐藏整个商店）。 |
| `source` | 空 或 `*` = 全源；否则按源名限定（大小写不敏感）。 |
| `sha256` | 包指纹，64 位 hex，忽略大小写与空白。空 = 不按指纹。不是 64 位 hex → **该条被丢弃并记一条告警**（其余条目照常生效）。 |
| `reason` | `malware` / `fraud` / `copyright` / `security` / `policy` / `author`，未知码原样回显。 |
| `notice` | 展示用说明，**只做展示、不参与判定**（判定仍只看 `app`/`source`/`sha256`/`until`）。上限 **60 字（按 rune 计）**：超长按 60 字截断并记一条告警——**条目不丢、清单不作废**。为空时前端副行回落「moo 已停止提供下载与更新」；卡面标题始终使用 `reason` 短句。 |
| `since` / `until` / `ref` | 生效日 / 到期日（`YYYY-MM-DD` 或 RFC3339，到期即失效）/ 追溯链接。 |

### 24.2 命中语义（AND）

一条命中一张卡，需要**同时**满足：

1. **名称**：`app` 空 → 跳过；否则 `EqualFold(app, 卡的应用名)`；
2. **源**：`source` 空或 `*` → 任意；否则 `EqualFold`；
3. **指纹**：`sha256` 空 → 不约束；否则**要求调用方包指纹已知且相等**；
4. **有效期**：`until` 未到期。

> ⚠️ 第 3 条的「指纹未知 → 不命中」是刻意的：sha 是版本级标识，拿不到就无从
> 判断这批包是不是被下架的那批，按旧指纹硬拦会把刚修好的新版本一起挡掉。

一张卡同时命中多条时，**展示字段按「最具体」取一条**（判定不受影响：命中任一条即命中）：

```
指纹 + 源  >  指纹  >  应用 + 源  >  应用
（同级取清单中靠前的一条）
```

> 这么挑是为了不让泛化的「违反社区规范」盖掉更严重的「检测到恶意行为」。
> 每条条目各带自己的 `notice`，多张卡不会串文案。

### 24.3 闸门（全部带包指纹）

| 闸门 | 位置 | 名称来源 | 指纹来源 |
|---|---|---|---|
| 目录打标（**保留卡**，不删） | `annotateBlacklisted` | `AppInfo.AppName`（**不用 DisplayName**） | `AppInfo.Sha256` |
| 详情 404（带原因，仅 key 已不在目录时兜底） | `blacklistHitByKey` | `resolveKey` 的 `App.Name` | 同一次 resolve 的 `a.Sha256` |
| 向导 | `appWizard` | `a.Name` | `a.Sha256` |
| 安装 / 暂存 / 更新（SSE） | `blacklistGuardSSE` | `a.Name` | `a.Sha256` |
| 后台下载 | `blacklistGuardSSE` | `a.Name` | `a.Sha256` |
| 自动更新跳过 | `autoUpdatePass` | `AppName`（含 `UpdateFromSource`） | `AppInfo.Sha256` |
| 手动更新队列 | `listManualUpdates` | `manualUpdateItem.App` | `manualUpdateItem.Sha` |
| 本地包安装（上传/KSpeeder/下载中心） | `installFpkFileSSE` | `staged.AppName` | 实算 `sha256File(staged.Path → 原 path)`，算不出传 `""` |

> **目录层语义（P1-4，2026-11-22 定稿）**：命中条目的卡**保留在列表里并打标**——已装卡与未装卡都不删除
> （「已下架」= 停止分发，不是已卸载；Moo 不做远程卸载，已装副本仍可打开，可由用户在卡上或飞牛应用中心卸载）。
> 命中卡额外下发 `blacklisted=true` / `blacklist_reason` / `blacklist_notice` / `blacklist_since`，
> 并把该卡的 `has_update` / `update_ignored` / `update_ignored_pending` **清零**（下架卡不能更新）。
> 前端据此显示「已下架」角标 + 原因浮层、隐藏安装/更新入口；**后端动作闸照旧拦截**（纵深防御——
> 前端只是不给必败的按钮）。详情页因此正常 **200**（不再 404）；仅在 key 已不在目录（旧缓存/深链）时
> 才回落到「404 带原因」。
>
> 新增下发字段（`AppInfo`，均 `omitempty`，只在命中时出现）：
>
> | 字段 | 说明 |
> |---|---|
> | `blacklisted` | `true` = 该卡命中黑名单（停止分发）。前端用它灰卡 + 角标。 |
> | `blacklist_reason` | 原因码原样小写（`malware`/`fraud`/`copyright`/`security`/`policy`/`author`；未知码也原样透出）。卡面不显示码，前端映射短句。 |
> | `blacklist_notice` | 清单 `notice`（≤60 字，已截断）。为空时前端副行回落「moo 已停止提供下载与更新」；卡面标题始终使用 `reason` 短句。 |
> | `blacklist_since` | 清单 `since` 原样透出（生效日）。 |
>
> 黑名单清单本身是远端文件，从未拉取成功时 fail-open（空清单），并把最近一次验签通过的清单落盘为 `blacklist_last.json`（0600）供重启/断网兜底。

文案（定稿，勿改）：动作拦截 = `该应用存在恶意行为，已被停止分发，无法下载`
（`reason=malware`）/ 其余 `该应用违反社区规范，已被停止分发，无法下载`；
详情 404 = `该应用已被停止分发（原因：<原因文案>）`。

### 24.4 误伤防护

- `app + sha256` 条目在调用方指纹未知时**不拦**（新版本不受旧指纹影响）；
- 目录与详情只认 `AppName`，`DisplayName` 与条目同名**不构成命中**；
- 名称匹配大小写不敏感（daemon `Gitea` vs feed `gitea`）；
- 单条坏数据（非法 sha）只丢该条，不作废整份清单；
- 清单从未拉取成功 → 空清单（fail-open），既不打标也不隐藏任何应用。
